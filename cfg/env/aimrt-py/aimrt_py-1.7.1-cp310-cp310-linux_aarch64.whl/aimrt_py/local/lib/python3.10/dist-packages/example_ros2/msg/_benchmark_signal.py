# generated from rosidl_generator_py/resource/_idl.py.em
# with input from example_ros2:msg/BenchmarkSignal.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_BenchmarkSignal(type):
    """Metaclass of message 'BenchmarkSignal'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('example_ros2')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'example_ros2.msg.BenchmarkSignal')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__benchmark_signal
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__benchmark_signal
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__benchmark_signal
            cls._TYPE_SUPPORT = module.type_support_msg__msg__benchmark_signal
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__benchmark_signal

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class BenchmarkSignal(metaclass=Metaclass_BenchmarkSignal):
    """Message class 'BenchmarkSignal'."""

    __slots__ = [
        '_status',
        '_bench_plan_id',
        '_mode',
        '_topic_number',
        '_parallel_number',
        '_send_num',
        '_message_size',
        '_send_frequency',
    ]

    _fields_and_field_types = {
        'status': 'uint8',
        'bench_plan_id': 'uint32',
        'mode': 'string',
        'topic_number': 'uint32',
        'parallel_number': 'uint32',
        'send_num': 'uint32',
        'message_size': 'uint32',
        'send_frequency': 'uint32',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.status = kwargs.get('status', int())
        self.bench_plan_id = kwargs.get('bench_plan_id', int())
        self.mode = kwargs.get('mode', str())
        self.topic_number = kwargs.get('topic_number', int())
        self.parallel_number = kwargs.get('parallel_number', int())
        self.send_num = kwargs.get('send_num', int())
        self.message_size = kwargs.get('message_size', int())
        self.send_frequency = kwargs.get('send_frequency', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.status != other.status:
            return False
        if self.bench_plan_id != other.bench_plan_id:
            return False
        if self.mode != other.mode:
            return False
        if self.topic_number != other.topic_number:
            return False
        if self.parallel_number != other.parallel_number:
            return False
        if self.send_num != other.send_num:
            return False
        if self.message_size != other.message_size:
            return False
        if self.send_frequency != other.send_frequency:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def status(self):
        """Message field 'status'."""
        return self._status

    @status.setter
    def status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'status' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'status' field must be an unsigned integer in [0, 255]"
        self._status = value

    @builtins.property
    def bench_plan_id(self):
        """Message field 'bench_plan_id'."""
        return self._bench_plan_id

    @bench_plan_id.setter
    def bench_plan_id(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'bench_plan_id' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'bench_plan_id' field must be an unsigned integer in [0, 4294967295]"
        self._bench_plan_id = value

    @builtins.property
    def mode(self):
        """Message field 'mode'."""
        return self._mode

    @mode.setter
    def mode(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'mode' field must be of type 'str'"
        self._mode = value

    @builtins.property
    def topic_number(self):
        """Message field 'topic_number'."""
        return self._topic_number

    @topic_number.setter
    def topic_number(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'topic_number' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'topic_number' field must be an unsigned integer in [0, 4294967295]"
        self._topic_number = value

    @builtins.property
    def parallel_number(self):
        """Message field 'parallel_number'."""
        return self._parallel_number

    @parallel_number.setter
    def parallel_number(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'parallel_number' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'parallel_number' field must be an unsigned integer in [0, 4294967295]"
        self._parallel_number = value

    @builtins.property
    def send_num(self):
        """Message field 'send_num'."""
        return self._send_num

    @send_num.setter
    def send_num(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'send_num' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'send_num' field must be an unsigned integer in [0, 4294967295]"
        self._send_num = value

    @builtins.property
    def message_size(self):
        """Message field 'message_size'."""
        return self._message_size

    @message_size.setter
    def message_size(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'message_size' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'message_size' field must be an unsigned integer in [0, 4294967295]"
        self._message_size = value

    @builtins.property
    def send_frequency(self):
        """Message field 'send_frequency'."""
        return self._send_frequency

    @send_frequency.setter
    def send_frequency(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'send_frequency' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'send_frequency' field must be an unsigned integer in [0, 4294967295]"
        self._send_frequency = value
