// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from example_ros2:msg/BenchmarkSignal.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "example_ros2/msg/detail/benchmark_signal__struct.h"
#include "example_ros2/msg/detail/benchmark_signal__functions.h"

#include "rosidl_runtime_c/string.h"
#include "rosidl_runtime_c/string_functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool example_ros2__msg__benchmark_signal__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[51];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("example_ros2.msg._benchmark_signal.BenchmarkSignal", full_classname_dest, 50) == 0);
  }
  example_ros2__msg__BenchmarkSignal * ros_message = _ros_message;
  {  // status
    PyObject * field = PyObject_GetAttrString(_pymsg, "status");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->status = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // bench_plan_id
    PyObject * field = PyObject_GetAttrString(_pymsg, "bench_plan_id");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->bench_plan_id = PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // mode
    PyObject * field = PyObject_GetAttrString(_pymsg, "mode");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->mode, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // topic_number
    PyObject * field = PyObject_GetAttrString(_pymsg, "topic_number");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->topic_number = PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // parallel_number
    PyObject * field = PyObject_GetAttrString(_pymsg, "parallel_number");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->parallel_number = PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // send_num
    PyObject * field = PyObject_GetAttrString(_pymsg, "send_num");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->send_num = PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // message_size
    PyObject * field = PyObject_GetAttrString(_pymsg, "message_size");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->message_size = PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // send_frequency
    PyObject * field = PyObject_GetAttrString(_pymsg, "send_frequency");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->send_frequency = PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * example_ros2__msg__benchmark_signal__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of BenchmarkSignal */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("example_ros2.msg._benchmark_signal");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "BenchmarkSignal");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  example_ros2__msg__BenchmarkSignal * ros_message = (example_ros2__msg__BenchmarkSignal *)raw_ros_message;
  {  // status
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->status);
    {
      int rc = PyObject_SetAttrString(_pymessage, "status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // bench_plan_id
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->bench_plan_id);
    {
      int rc = PyObject_SetAttrString(_pymessage, "bench_plan_id", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // mode
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->mode.data,
      strlen(ros_message->mode.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "mode", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // topic_number
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->topic_number);
    {
      int rc = PyObject_SetAttrString(_pymessage, "topic_number", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // parallel_number
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->parallel_number);
    {
      int rc = PyObject_SetAttrString(_pymessage, "parallel_number", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // send_num
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->send_num);
    {
      int rc = PyObject_SetAttrString(_pymessage, "send_num", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // message_size
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->message_size);
    {
      int rc = PyObject_SetAttrString(_pymessage, "message_size", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // send_frequency
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->send_frequency);
    {
      int rc = PyObject_SetAttrString(_pymessage, "send_frequency", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
