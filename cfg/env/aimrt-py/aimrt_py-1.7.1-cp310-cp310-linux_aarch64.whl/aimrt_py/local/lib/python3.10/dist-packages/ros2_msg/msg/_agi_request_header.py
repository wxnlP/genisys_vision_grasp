# generated from rosidl_generator_py/resource/_idl.py.em
# with input from ros2_msg:msg/AgiRequestHeader.idl
# generated code does not contain a copyright notice


# Import statements for member types

# Member 'extra_attr'
import array  # noqa: E402, I100

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_AgiRequestHeader(type):
    """Metaclass of message 'AgiRequestHeader'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('ros2_msg')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'ros2_msg.msg.AgiRequestHeader')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__agi_request_header
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__agi_request_header
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__agi_request_header
            cls._TYPE_SUPPORT = module.type_support_msg__msg__agi_request_header
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__agi_request_header

            from ros2_msg.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class AgiRequestHeader(metaclass=Metaclass_AgiRequestHeader):
    """Message class 'AgiRequestHeader'."""

    __slots__ = [
        '_request_id',
        '_client_name',
        '_request_time',
        '_extra_attr',
    ]

    _fields_and_field_types = {
        'request_id': 'uint32',
        'client_name': 'string',
        'request_time': 'ros2_msg/Time',
        'extra_attr': 'sequence<uint8>',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['ros2_msg', 'msg'], 'Time'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('uint8')),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.request_id = kwargs.get('request_id', int())
        self.client_name = kwargs.get('client_name', str())
        from ros2_msg.msg import Time
        self.request_time = kwargs.get('request_time', Time())
        self.extra_attr = array.array('B', kwargs.get('extra_attr', []))

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.request_id != other.request_id:
            return False
        if self.client_name != other.client_name:
            return False
        if self.request_time != other.request_time:
            return False
        if self.extra_attr != other.extra_attr:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def request_id(self):
        """Message field 'request_id'."""
        return self._request_id

    @request_id.setter
    def request_id(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'request_id' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'request_id' field must be an unsigned integer in [0, 4294967295]"
        self._request_id = value

    @builtins.property
    def client_name(self):
        """Message field 'client_name'."""
        return self._client_name

    @client_name.setter
    def client_name(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'client_name' field must be of type 'str'"
        self._client_name = value

    @builtins.property
    def request_time(self):
        """Message field 'request_time'."""
        return self._request_time

    @request_time.setter
    def request_time(self, value):
        if __debug__:
            from ros2_msg.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'request_time' field must be a sub message of type 'Time'"
        self._request_time = value

    @builtins.property
    def extra_attr(self):
        """Message field 'extra_attr'."""
        return self._extra_attr

    @extra_attr.setter
    def extra_attr(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'B', \
                "The 'extra_attr' array.array() must have the type code of 'B'"
            self._extra_attr = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, int) for v in value) and
                 all(val >= 0 and val < 256 for val in value)), \
                "The 'extra_attr' field must be a set or sequence and each value of type 'int' and each unsigned integer in [0, 255]"
        self._extra_attr = array.array('B', value)
