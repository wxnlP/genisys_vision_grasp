# generated from rosidl_generator_py/resource/_idl.py.em
# with input from example_ros2:msg/RosTestMsg.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_RosTestMsg(type):
    """Metaclass of message 'RosTestMsg'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('example_ros2')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'example_ros2.msg.RosTestMsg')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__ros_test_msg
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__ros_test_msg
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__ros_test_msg
            cls._TYPE_SUPPORT = module.type_support_msg__msg__ros_test_msg
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__ros_test_msg

            from example_ros2.msg import RosTestData
            if RosTestData.__class__._TYPE_SUPPORT is None:
                RosTestData.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class RosTestMsg(metaclass=Metaclass_RosTestMsg):
    """Message class 'RosTestMsg'."""

    __slots__ = [
        '_num',
        '_data',
        '_test_msg2',
    ]

    _fields_and_field_types = {
        'num': 'int64',
        'data': 'sequence<octet>',
        'test_msg2': 'example_ros2/RosTestData',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int64'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('octet')),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['example_ros2', 'msg'], 'RosTestData'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.num = kwargs.get('num', int())
        self.data = kwargs.get('data', [])
        from example_ros2.msg import RosTestData
        self.test_msg2 = kwargs.get('test_msg2', RosTestData())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.num != other.num:
            return False
        if self.data != other.data:
            return False
        if self.test_msg2 != other.test_msg2:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def num(self):
        """Message field 'num'."""
        return self._num

    @num.setter
    def num(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'num' field must be of type 'int'"
            assert value >= -9223372036854775808 and value < 9223372036854775808, \
                "The 'num' field must be an integer in [-9223372036854775808, 9223372036854775807]"
        self._num = value

    @builtins.property
    def data(self):
        """Message field 'data'."""
        return self._data

    @data.setter
    def data(self, value):
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, bytes) for v in value) and
                 True), \
                "The 'data' field must be a set or sequence and each value of type 'bytes'"
        self._data = value

    @builtins.property
    def test_msg2(self):
        """Message field 'test_msg2'."""
        return self._test_msg2

    @test_msg2.setter
    def test_msg2(self, value):
        if __debug__:
            from example_ros2.msg import RosTestData
            assert \
                isinstance(value, RosTestData), \
                "The 'test_msg2' field must be a sub message of type 'RosTestData'"
        self._test_msg2 = value
