#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to ros2_msg__msg__Time

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Time {

    // This member is not documented.
    #[allow(missing_docs)]
    pub seconds: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub fraction: u32,

}



impl Default for Time {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Time::default())
  }
}

impl rosidl_runtime_rs::Message for Time {
  type RmwMsg = super::msg::rmw::Time;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        seconds: msg.seconds,
        fraction: msg.fraction,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      seconds: msg.seconds,
      fraction: msg.fraction,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      seconds: msg.seconds,
      fraction: msg.fraction,
    }
  }
}


// Corresponds to ros2_msg__msg__AgiHeader

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AgiHeader {

    // This member is not documented.
    #[allow(missing_docs)]
    pub seq_num: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub publisher_name: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub publish_time: super::msg::Time,


    // This member is not documented.
    #[allow(missing_docs)]
    pub generate_timestamp: super::msg::Time,


    // This member is not documented.
    #[allow(missing_docs)]
    pub extra_attr: Vec<u8>,

}



impl Default for AgiHeader {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::AgiHeader::default())
  }
}

impl rosidl_runtime_rs::Message for AgiHeader {
  type RmwMsg = super::msg::rmw::AgiHeader;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        seq_num: msg.seq_num,
        publisher_name: msg.publisher_name.as_str().into(),
        publish_time: super::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.publish_time)).into_owned(),
        generate_timestamp: super::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.generate_timestamp)).into_owned(),
        extra_attr: msg.extra_attr.as_slice().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      seq_num: msg.seq_num,
        publisher_name: msg.publisher_name.as_str().into(),
        publish_time: super::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.publish_time)).into_owned(),
        generate_timestamp: super::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.generate_timestamp)).into_owned(),
        extra_attr: msg.extra_attr.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      seq_num: msg.seq_num,
      publisher_name: msg.publisher_name.to_string(),
      publish_time: super::msg::Time::from_rmw_message(msg.publish_time),
      generate_timestamp: super::msg::Time::from_rmw_message(msg.generate_timestamp),
      extra_attr: msg.extra_attr.into(),
    }
  }
}


// Corresponds to ros2_msg__msg__AgiRequestHeader

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AgiRequestHeader {

    // This member is not documented.
    #[allow(missing_docs)]
    pub request_id: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub client_name: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub request_time: super::msg::Time,


    // This member is not documented.
    #[allow(missing_docs)]
    pub extra_attr: Vec<u8>,

}



impl Default for AgiRequestHeader {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::AgiRequestHeader::default())
  }
}

impl rosidl_runtime_rs::Message for AgiRequestHeader {
  type RmwMsg = super::msg::rmw::AgiRequestHeader;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        request_id: msg.request_id,
        client_name: msg.client_name.as_str().into(),
        request_time: super::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.request_time)).into_owned(),
        extra_attr: msg.extra_attr.as_slice().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      request_id: msg.request_id,
        client_name: msg.client_name.as_str().into(),
        request_time: super::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.request_time)).into_owned(),
        extra_attr: msg.extra_attr.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      request_id: msg.request_id,
      client_name: msg.client_name.to_string(),
      request_time: super::msg::Time::from_rmw_message(msg.request_time),
      extra_attr: msg.extra_attr.into(),
    }
  }
}


// Corresponds to ros2_msg__msg__AgiHeaderExampleMsg

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AgiHeaderExampleMsg {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: super::msg::AgiHeader,


    // This member is not documented.
    #[allow(missing_docs)]
    pub payload: std::string::String,

}



impl Default for AgiHeaderExampleMsg {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::AgiHeaderExampleMsg::default())
  }
}

impl rosidl_runtime_rs::Message for AgiHeaderExampleMsg {
  type RmwMsg = super::msg::rmw::AgiHeaderExampleMsg;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: super::msg::AgiHeader::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        payload: msg.payload.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: super::msg::AgiHeader::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        payload: msg.payload.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: super::msg::AgiHeader::from_rmw_message(msg.header),
      payload: msg.payload.to_string(),
    }
  }
}


