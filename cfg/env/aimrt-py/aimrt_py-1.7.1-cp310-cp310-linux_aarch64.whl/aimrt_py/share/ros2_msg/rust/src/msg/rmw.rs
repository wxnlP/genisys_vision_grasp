#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "ros2_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ros2_msg__msg__Time() -> *const std::ffi::c_void;
}

#[link(name = "ros2_msg__rosidl_generator_c")]
extern "C" {
    fn ros2_msg__msg__Time__init(msg: *mut Time) -> bool;
    fn ros2_msg__msg__Time__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Time>, size: usize) -> bool;
    fn ros2_msg__msg__Time__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Time>);
    fn ros2_msg__msg__Time__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Time>, out_seq: *mut rosidl_runtime_rs::Sequence<Time>) -> bool;
}

// Corresponds to ros2_msg__msg__Time
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Time {

    // This member is not documented.
    #[allow(missing_docs)]
    pub seconds: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub fraction: u32,

}



impl Default for Time {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ros2_msg__msg__Time__init(&mut msg as *mut _) {
        panic!("Call to ros2_msg__msg__Time__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Time {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ros2_msg__msg__Time__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ros2_msg__msg__Time__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ros2_msg__msg__Time__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Time {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Time where Self: Sized {
  const TYPE_NAME: &'static str = "ros2_msg/msg/Time";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ros2_msg__msg__Time() }
  }
}


#[link(name = "ros2_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ros2_msg__msg__AgiHeader() -> *const std::ffi::c_void;
}

#[link(name = "ros2_msg__rosidl_generator_c")]
extern "C" {
    fn ros2_msg__msg__AgiHeader__init(msg: *mut AgiHeader) -> bool;
    fn ros2_msg__msg__AgiHeader__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<AgiHeader>, size: usize) -> bool;
    fn ros2_msg__msg__AgiHeader__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<AgiHeader>);
    fn ros2_msg__msg__AgiHeader__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<AgiHeader>, out_seq: *mut rosidl_runtime_rs::Sequence<AgiHeader>) -> bool;
}

// Corresponds to ros2_msg__msg__AgiHeader
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AgiHeader {

    // This member is not documented.
    #[allow(missing_docs)]
    pub seq_num: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub publisher_name: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub publish_time: super::super::msg::rmw::Time,


    // This member is not documented.
    #[allow(missing_docs)]
    pub generate_timestamp: super::super::msg::rmw::Time,


    // This member is not documented.
    #[allow(missing_docs)]
    pub extra_attr: rosidl_runtime_rs::Sequence<u8>,

}



impl Default for AgiHeader {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ros2_msg__msg__AgiHeader__init(&mut msg as *mut _) {
        panic!("Call to ros2_msg__msg__AgiHeader__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for AgiHeader {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ros2_msg__msg__AgiHeader__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ros2_msg__msg__AgiHeader__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ros2_msg__msg__AgiHeader__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for AgiHeader {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for AgiHeader where Self: Sized {
  const TYPE_NAME: &'static str = "ros2_msg/msg/AgiHeader";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ros2_msg__msg__AgiHeader() }
  }
}


#[link(name = "ros2_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ros2_msg__msg__AgiRequestHeader() -> *const std::ffi::c_void;
}

#[link(name = "ros2_msg__rosidl_generator_c")]
extern "C" {
    fn ros2_msg__msg__AgiRequestHeader__init(msg: *mut AgiRequestHeader) -> bool;
    fn ros2_msg__msg__AgiRequestHeader__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<AgiRequestHeader>, size: usize) -> bool;
    fn ros2_msg__msg__AgiRequestHeader__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<AgiRequestHeader>);
    fn ros2_msg__msg__AgiRequestHeader__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<AgiRequestHeader>, out_seq: *mut rosidl_runtime_rs::Sequence<AgiRequestHeader>) -> bool;
}

// Corresponds to ros2_msg__msg__AgiRequestHeader
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AgiRequestHeader {

    // This member is not documented.
    #[allow(missing_docs)]
    pub request_id: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub client_name: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub request_time: super::super::msg::rmw::Time,


    // This member is not documented.
    #[allow(missing_docs)]
    pub extra_attr: rosidl_runtime_rs::Sequence<u8>,

}



impl Default for AgiRequestHeader {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ros2_msg__msg__AgiRequestHeader__init(&mut msg as *mut _) {
        panic!("Call to ros2_msg__msg__AgiRequestHeader__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for AgiRequestHeader {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ros2_msg__msg__AgiRequestHeader__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ros2_msg__msg__AgiRequestHeader__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ros2_msg__msg__AgiRequestHeader__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for AgiRequestHeader {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for AgiRequestHeader where Self: Sized {
  const TYPE_NAME: &'static str = "ros2_msg/msg/AgiRequestHeader";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ros2_msg__msg__AgiRequestHeader() }
  }
}


#[link(name = "ros2_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ros2_msg__msg__AgiHeaderExampleMsg() -> *const std::ffi::c_void;
}

#[link(name = "ros2_msg__rosidl_generator_c")]
extern "C" {
    fn ros2_msg__msg__AgiHeaderExampleMsg__init(msg: *mut AgiHeaderExampleMsg) -> bool;
    fn ros2_msg__msg__AgiHeaderExampleMsg__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<AgiHeaderExampleMsg>, size: usize) -> bool;
    fn ros2_msg__msg__AgiHeaderExampleMsg__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<AgiHeaderExampleMsg>);
    fn ros2_msg__msg__AgiHeaderExampleMsg__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<AgiHeaderExampleMsg>, out_seq: *mut rosidl_runtime_rs::Sequence<AgiHeaderExampleMsg>) -> bool;
}

// Corresponds to ros2_msg__msg__AgiHeaderExampleMsg
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AgiHeaderExampleMsg {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: super::super::msg::rmw::AgiHeader,


    // This member is not documented.
    #[allow(missing_docs)]
    pub payload: rosidl_runtime_rs::String,

}



impl Default for AgiHeaderExampleMsg {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ros2_msg__msg__AgiHeaderExampleMsg__init(&mut msg as *mut _) {
        panic!("Call to ros2_msg__msg__AgiHeaderExampleMsg__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for AgiHeaderExampleMsg {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ros2_msg__msg__AgiHeaderExampleMsg__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ros2_msg__msg__AgiHeaderExampleMsg__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ros2_msg__msg__AgiHeaderExampleMsg__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for AgiHeaderExampleMsg {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for AgiHeaderExampleMsg where Self: Sized {
  const TYPE_NAME: &'static str = "ros2_msg/msg/AgiHeaderExampleMsg";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ros2_msg__msg__AgiHeaderExampleMsg() }
  }
}


