# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(ros2_msg_IDL_FILES "msg/Time.idl;msg/AgiHeader.idl;msg/AgiRequestHeader.idl;msg/AgiHeaderExampleMsg.idl")
set(ros2_msg_INTERFACE_FILES "msg/Time.msg;msg/AgiHeader.msg;msg/AgiRequestHeader.msg;msg/AgiHeaderExampleMsg.msg")
