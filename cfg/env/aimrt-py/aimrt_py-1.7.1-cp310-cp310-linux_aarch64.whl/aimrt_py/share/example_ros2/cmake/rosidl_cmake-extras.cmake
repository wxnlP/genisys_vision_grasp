# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(example_ros2_IDL_FILES "msg/RosTestMsg.idl;msg/RosTestData.idl;msg/BenchmarkMessage.idl;msg/BenchmarkSignal.idl;msg/BenchmarkStatus.idl;srv/RosTestRpc.idl")
set(example_ros2_INTERFACE_FILES "msg/RosTestMsg.msg;msg/RosTestData.msg;msg/BenchmarkMessage.msg;msg/BenchmarkSignal.msg;msg/BenchmarkStatus.msg;srv/RosTestRpc.srv;srv/RosTestRpc_Request.msg;srv/RosTestRpc_Response.msg")
