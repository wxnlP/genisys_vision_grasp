#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to example_ros2__msg__RosTestMsg

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RosTestMsg {

    // This member is not documented.
    #[allow(missing_docs)]
    pub num: i64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: Vec<u8>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub test_msg2: super::msg::RosTestData,

}



impl Default for RosTestMsg {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::RosTestMsg::default())
  }
}

impl rosidl_runtime_rs::Message for RosTestMsg {
  type RmwMsg = super::msg::rmw::RosTestMsg;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        num: msg.num,
        data: msg.data.as_slice().into(),
        test_msg2: super::msg::RosTestData::into_rmw_message(std::borrow::Cow::Owned(msg.test_msg2)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      num: msg.num,
        data: msg.data.as_slice().into(),
        test_msg2: super::msg::RosTestData::into_rmw_message(std::borrow::Cow::Borrowed(&msg.test_msg2)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      num: msg.num,
      data: msg.data.into(),
      test_msg2: super::msg::RosTestData::from_rmw_message(msg.test_msg2),
    }
  }
}


// Corresponds to example_ros2__msg__RosTestData

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RosTestData {

    // This member is not documented.
    #[allow(missing_docs)]
    pub num: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub num2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: u8,

}



impl Default for RosTestData {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::RosTestData::default())
  }
}

impl rosidl_runtime_rs::Message for RosTestData {
  type RmwMsg = super::msg::rmw::RosTestData;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        num: msg.num,
        num2: msg.num2,
        data: msg.data,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      num: msg.num,
      num2: msg.num2,
      data: msg.data,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      num: msg.num,
      num2: msg.num2,
      data: msg.data,
    }
  }
}


// Corresponds to example_ros2__msg__BenchmarkMessage

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BenchmarkMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub seq: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: Vec<u8>,

}



impl Default for BenchmarkMessage {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::BenchmarkMessage::default())
  }
}

impl rosidl_runtime_rs::Message for BenchmarkMessage {
  type RmwMsg = super::msg::rmw::BenchmarkMessage;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        seq: msg.seq,
        timestamp: msg.timestamp,
        data: msg.data.as_slice().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      seq: msg.seq,
      timestamp: msg.timestamp,
        data: msg.data.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      seq: msg.seq,
      timestamp: msg.timestamp,
      data: msg.data.into(),
    }
  }
}


// Corresponds to example_ros2__msg__BenchmarkSignal

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BenchmarkSignal {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bench_plan_id: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mode: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub topic_number: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub parallel_number: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub send_num: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message_size: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub send_frequency: u32,

}



impl Default for BenchmarkSignal {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::BenchmarkSignal::default())
  }
}

impl rosidl_runtime_rs::Message for BenchmarkSignal {
  type RmwMsg = super::msg::rmw::BenchmarkSignal;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        bench_plan_id: msg.bench_plan_id,
        mode: msg.mode.as_str().into(),
        topic_number: msg.topic_number,
        parallel_number: msg.parallel_number,
        send_num: msg.send_num,
        message_size: msg.message_size,
        send_frequency: msg.send_frequency,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
      bench_plan_id: msg.bench_plan_id,
        mode: msg.mode.as_str().into(),
      topic_number: msg.topic_number,
      parallel_number: msg.parallel_number,
      send_num: msg.send_num,
      message_size: msg.message_size,
      send_frequency: msg.send_frequency,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      bench_plan_id: msg.bench_plan_id,
      mode: msg.mode.to_string(),
      topic_number: msg.topic_number,
      parallel_number: msg.parallel_number,
      send_num: msg.send_num,
      message_size: msg.message_size,
      send_frequency: msg.send_frequency,
    }
  }
}


// Corresponds to example_ros2__msg__BenchmarkStatus

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BenchmarkStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,

}

impl BenchmarkStatus {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const BEGIN: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const END: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const WARM_UP: u8 = 2;

}


impl Default for BenchmarkStatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::BenchmarkStatus::default())
  }
}

impl rosidl_runtime_rs::Message for BenchmarkStatus {
  type RmwMsg = super::msg::rmw::BenchmarkStatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
    }
  }
}


