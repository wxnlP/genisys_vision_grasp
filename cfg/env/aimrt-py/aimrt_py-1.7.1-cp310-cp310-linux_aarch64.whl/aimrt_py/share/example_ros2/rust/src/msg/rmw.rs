#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "example_ros2__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__example_ros2__msg__RosTestMsg() -> *const std::ffi::c_void;
}

#[link(name = "example_ros2__rosidl_generator_c")]
extern "C" {
    fn example_ros2__msg__RosTestMsg__init(msg: *mut RosTestMsg) -> bool;
    fn example_ros2__msg__RosTestMsg__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<RosTestMsg>, size: usize) -> bool;
    fn example_ros2__msg__RosTestMsg__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<RosTestMsg>);
    fn example_ros2__msg__RosTestMsg__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<RosTestMsg>, out_seq: *mut rosidl_runtime_rs::Sequence<RosTestMsg>) -> bool;
}

// Corresponds to example_ros2__msg__RosTestMsg
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RosTestMsg {

    // This member is not documented.
    #[allow(missing_docs)]
    pub num: i64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: rosidl_runtime_rs::Sequence<u8>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub test_msg2: super::super::msg::rmw::RosTestData,

}



impl Default for RosTestMsg {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !example_ros2__msg__RosTestMsg__init(&mut msg as *mut _) {
        panic!("Call to example_ros2__msg__RosTestMsg__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for RosTestMsg {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__RosTestMsg__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__RosTestMsg__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__RosTestMsg__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for RosTestMsg {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for RosTestMsg where Self: Sized {
  const TYPE_NAME: &'static str = "example_ros2/msg/RosTestMsg";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__example_ros2__msg__RosTestMsg() }
  }
}


#[link(name = "example_ros2__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__example_ros2__msg__RosTestData() -> *const std::ffi::c_void;
}

#[link(name = "example_ros2__rosidl_generator_c")]
extern "C" {
    fn example_ros2__msg__RosTestData__init(msg: *mut RosTestData) -> bool;
    fn example_ros2__msg__RosTestData__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<RosTestData>, size: usize) -> bool;
    fn example_ros2__msg__RosTestData__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<RosTestData>);
    fn example_ros2__msg__RosTestData__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<RosTestData>, out_seq: *mut rosidl_runtime_rs::Sequence<RosTestData>) -> bool;
}

// Corresponds to example_ros2__msg__RosTestData
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RosTestData {

    // This member is not documented.
    #[allow(missing_docs)]
    pub num: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub num2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: u8,

}



impl Default for RosTestData {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !example_ros2__msg__RosTestData__init(&mut msg as *mut _) {
        panic!("Call to example_ros2__msg__RosTestData__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for RosTestData {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__RosTestData__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__RosTestData__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__RosTestData__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for RosTestData {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for RosTestData where Self: Sized {
  const TYPE_NAME: &'static str = "example_ros2/msg/RosTestData";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__example_ros2__msg__RosTestData() }
  }
}


#[link(name = "example_ros2__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__example_ros2__msg__BenchmarkMessage() -> *const std::ffi::c_void;
}

#[link(name = "example_ros2__rosidl_generator_c")]
extern "C" {
    fn example_ros2__msg__BenchmarkMessage__init(msg: *mut BenchmarkMessage) -> bool;
    fn example_ros2__msg__BenchmarkMessage__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<BenchmarkMessage>, size: usize) -> bool;
    fn example_ros2__msg__BenchmarkMessage__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<BenchmarkMessage>);
    fn example_ros2__msg__BenchmarkMessage__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<BenchmarkMessage>, out_seq: *mut rosidl_runtime_rs::Sequence<BenchmarkMessage>) -> bool;
}

// Corresponds to example_ros2__msg__BenchmarkMessage
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BenchmarkMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub seq: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: rosidl_runtime_rs::Sequence<u8>,

}



impl Default for BenchmarkMessage {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !example_ros2__msg__BenchmarkMessage__init(&mut msg as *mut _) {
        panic!("Call to example_ros2__msg__BenchmarkMessage__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for BenchmarkMessage {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__BenchmarkMessage__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__BenchmarkMessage__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__BenchmarkMessage__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for BenchmarkMessage {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for BenchmarkMessage where Self: Sized {
  const TYPE_NAME: &'static str = "example_ros2/msg/BenchmarkMessage";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__example_ros2__msg__BenchmarkMessage() }
  }
}


#[link(name = "example_ros2__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__example_ros2__msg__BenchmarkSignal() -> *const std::ffi::c_void;
}

#[link(name = "example_ros2__rosidl_generator_c")]
extern "C" {
    fn example_ros2__msg__BenchmarkSignal__init(msg: *mut BenchmarkSignal) -> bool;
    fn example_ros2__msg__BenchmarkSignal__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<BenchmarkSignal>, size: usize) -> bool;
    fn example_ros2__msg__BenchmarkSignal__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<BenchmarkSignal>);
    fn example_ros2__msg__BenchmarkSignal__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<BenchmarkSignal>, out_seq: *mut rosidl_runtime_rs::Sequence<BenchmarkSignal>) -> bool;
}

// Corresponds to example_ros2__msg__BenchmarkSignal
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BenchmarkSignal {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bench_plan_id: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mode: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub topic_number: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub parallel_number: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub send_num: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message_size: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub send_frequency: u32,

}



impl Default for BenchmarkSignal {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !example_ros2__msg__BenchmarkSignal__init(&mut msg as *mut _) {
        panic!("Call to example_ros2__msg__BenchmarkSignal__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for BenchmarkSignal {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__BenchmarkSignal__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__BenchmarkSignal__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__BenchmarkSignal__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for BenchmarkSignal {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for BenchmarkSignal where Self: Sized {
  const TYPE_NAME: &'static str = "example_ros2/msg/BenchmarkSignal";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__example_ros2__msg__BenchmarkSignal() }
  }
}


#[link(name = "example_ros2__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__example_ros2__msg__BenchmarkStatus() -> *const std::ffi::c_void;
}

#[link(name = "example_ros2__rosidl_generator_c")]
extern "C" {
    fn example_ros2__msg__BenchmarkStatus__init(msg: *mut BenchmarkStatus) -> bool;
    fn example_ros2__msg__BenchmarkStatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<BenchmarkStatus>, size: usize) -> bool;
    fn example_ros2__msg__BenchmarkStatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<BenchmarkStatus>);
    fn example_ros2__msg__BenchmarkStatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<BenchmarkStatus>, out_seq: *mut rosidl_runtime_rs::Sequence<BenchmarkStatus>) -> bool;
}

// Corresponds to example_ros2__msg__BenchmarkStatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BenchmarkStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,

}

impl BenchmarkStatus {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const BEGIN: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const END: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const WARM_UP: u8 = 2;

}


impl Default for BenchmarkStatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !example_ros2__msg__BenchmarkStatus__init(&mut msg as *mut _) {
        panic!("Call to example_ros2__msg__BenchmarkStatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for BenchmarkStatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__BenchmarkStatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__BenchmarkStatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__msg__BenchmarkStatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for BenchmarkStatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for BenchmarkStatus where Self: Sized {
  const TYPE_NAME: &'static str = "example_ros2/msg/BenchmarkStatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__example_ros2__msg__BenchmarkStatus() }
  }
}


