#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};




// Corresponds to example_ros2__srv__RosTestRpc_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RosTestRpc_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub data: Vec<u8>,

}



impl Default for RosTestRpc_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::RosTestRpc_Request::default())
  }
}

impl rosidl_runtime_rs::Message for RosTestRpc_Request {
  type RmwMsg = super::srv::rmw::RosTestRpc_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        data: msg.data.as_slice().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        data: msg.data.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      data: msg.data.into(),
    }
  }
}


// Corresponds to example_ros2__srv__RosTestRpc_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RosTestRpc_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub code: i64,

}



impl Default for RosTestRpc_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::RosTestRpc_Response::default())
  }
}

impl rosidl_runtime_rs::Message for RosTestRpc_Response {
  type RmwMsg = super::srv::rmw::RosTestRpc_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        code: msg.code,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      code: msg.code,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      code: msg.code,
    }
  }
}






#[link(name = "example_ros2__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__example_ros2__srv__RosTestRpc() -> *const std::ffi::c_void;
}

// Corresponds to example_ros2__srv__RosTestRpc
#[allow(missing_docs, non_camel_case_types)]
pub struct RosTestRpc;

impl rosidl_runtime_rs::Service for RosTestRpc {
    type Request = RosTestRpc_Request;
    type Response = RosTestRpc_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__example_ros2__srv__RosTestRpc() }
    }
}


