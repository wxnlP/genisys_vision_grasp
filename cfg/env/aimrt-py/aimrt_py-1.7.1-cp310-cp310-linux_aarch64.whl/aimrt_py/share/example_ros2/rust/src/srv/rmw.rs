#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



#[link(name = "example_ros2__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__example_ros2__srv__RosTestRpc_Request() -> *const std::ffi::c_void;
}

#[link(name = "example_ros2__rosidl_generator_c")]
extern "C" {
    fn example_ros2__srv__RosTestRpc_Request__init(msg: *mut RosTestRpc_Request) -> bool;
    fn example_ros2__srv__RosTestRpc_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<RosTestRpc_Request>, size: usize) -> bool;
    fn example_ros2__srv__RosTestRpc_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<RosTestRpc_Request>);
    fn example_ros2__srv__RosTestRpc_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<RosTestRpc_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<RosTestRpc_Request>) -> bool;
}

// Corresponds to example_ros2__srv__RosTestRpc_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RosTestRpc_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub data: rosidl_runtime_rs::Sequence<u8>,

}



impl Default for RosTestRpc_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !example_ros2__srv__RosTestRpc_Request__init(&mut msg as *mut _) {
        panic!("Call to example_ros2__srv__RosTestRpc_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for RosTestRpc_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__srv__RosTestRpc_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__srv__RosTestRpc_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__srv__RosTestRpc_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for RosTestRpc_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for RosTestRpc_Request where Self: Sized {
  const TYPE_NAME: &'static str = "example_ros2/srv/RosTestRpc_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__example_ros2__srv__RosTestRpc_Request() }
  }
}


#[link(name = "example_ros2__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__example_ros2__srv__RosTestRpc_Response() -> *const std::ffi::c_void;
}

#[link(name = "example_ros2__rosidl_generator_c")]
extern "C" {
    fn example_ros2__srv__RosTestRpc_Response__init(msg: *mut RosTestRpc_Response) -> bool;
    fn example_ros2__srv__RosTestRpc_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<RosTestRpc_Response>, size: usize) -> bool;
    fn example_ros2__srv__RosTestRpc_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<RosTestRpc_Response>);
    fn example_ros2__srv__RosTestRpc_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<RosTestRpc_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<RosTestRpc_Response>) -> bool;
}

// Corresponds to example_ros2__srv__RosTestRpc_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RosTestRpc_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub code: i64,

}



impl Default for RosTestRpc_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !example_ros2__srv__RosTestRpc_Response__init(&mut msg as *mut _) {
        panic!("Call to example_ros2__srv__RosTestRpc_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for RosTestRpc_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__srv__RosTestRpc_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__srv__RosTestRpc_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { example_ros2__srv__RosTestRpc_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for RosTestRpc_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for RosTestRpc_Response where Self: Sized {
  const TYPE_NAME: &'static str = "example_ros2/srv/RosTestRpc_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__example_ros2__srv__RosTestRpc_Response() }
  }
}






#[link(name = "example_ros2__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__example_ros2__srv__RosTestRpc() -> *const std::ffi::c_void;
}

// Corresponds to example_ros2__srv__RosTestRpc
#[allow(missing_docs, non_camel_case_types)]
pub struct RosTestRpc;

impl rosidl_runtime_rs::Service for RosTestRpc {
    type Request = RosTestRpc_Request;
    type Response = RosTestRpc_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__example_ros2__srv__RosTestRpc() }
    }
}


